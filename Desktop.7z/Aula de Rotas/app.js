// O que é o protocolo HTTP ?
// HTTP é  um protocolo de comunicação que permeite que os computadores de comunique entre si.
// Ele usado para transferir dados entre um cliente (navegador) e um servidor (como um site).
// O Http é baseado em requisições e responder e é usado para realizar operações como CRIAR, LER, ATUALIZAR E EXCLUIR DADSOS (CRUD).

const http = require('http');

// Abrir um servidor http com a função listen
// A função listen referencia em qual porta de rede vamos inciar o servidor;.
// O servidor ira ouvir requisisções na porta  8081

http.createServer((req, res)=>{
    res.end('Hello World');
}).listen(8081);

console.log("Servidor rodando!");