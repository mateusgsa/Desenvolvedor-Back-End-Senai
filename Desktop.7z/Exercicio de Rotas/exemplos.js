//Como o modulo HTTP convencional em node.js é limitado, utlizaremos uma framework para potencialiazar nossas aplicações.
// Express é um dos frameworks mais populares para criar aplicações web em node.js
// ELe oferece uma serie de recursos e funcionalidades que facilitam a criação de aplicativos robustos e escalaveis.
// Para instlaar o framework Express digite no terminal "npm install express --save".

const express = require('express');

const app = express();

app.get("/", (req, res)=>{
    res.send("<h1>Hello World!</h1>");
});

app.get("/editar/:nome/:idade/:telefone", (req, res) => {
    const {nome, idade, telefone} = req.params;
    res.send(`
        <h1> Alterando Cadastro </h1>
        <form>
            <input type='text' value='${nome}' placeholder='Nome'>
            <br><br>
            <input type='number' value='${idade}' placeholder='Idade'>
            <br><br>
            <input type='tel' value='${telefone}' placeholder='Telefone'>
        </form>
        `);
});

app.get("/querys", (req, res)=>{
    const {nome, idade, telefone} = req.query;
    res.send(`
        <h1> Alterando Cadastro Usando Query</h1>
        <form>
            <input type='text' value='${nome}' placeholder='Nome'>
            <br><br>
            <input type='number' value='${idade}' placeholder='Idade'>
            <br><br>
            <input type='tel' value='${telefone}' placeholder='Telefone'>
        </form>
        `);
});

app.use(express.json());

app.post("/Cadastrar", (req, res)=>{
    const {nome, idade} = req.body;
    res.send(`Olá ${nome}, você tem ${idade} anos`);
});


app.put("/atualizar/:id", (req, res)=>{
    const id = req.params.id;
    const {nome, idade} = req.body;

    res.send(`Usuário de ID ${id} foi atualizado com o nome: ${nome}. E a idade: ${idade}`);
});

app.delete("/deletar/:id", (req, res)=>{
    const id = req.params.id;
    res.send(`Uduário de ID ${id}, foi deletado do banco de dados.`);
});

app.listen(8081, ()=>{
    console.log("Servidor foi iniciado na porta 8081");
});
