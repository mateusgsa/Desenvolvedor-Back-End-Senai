/* 1) Crie uma rota GET que colete o nome e a idade do usuário através de parâmetros da URL  
A aplicação deve verificar se o usuário é maior ou menor de idade.
Se o usuário for maior de idade, a aplicação deve responder com a mensagem:
Olá, [nome]! Você é maior de idade.
Se o usuário for menor de idade, a aplicação deve responder com:
Olá, [nome]! Você é menor de idade. */

const express = require('express');
const app = express();

app.get ("/calcular/:nome/:idade",(req, res)=>{
    const {nome, idade} = req.params;
    if (idade>= 18){
        res.send(`O usuário ${nome}, tem ${idade} anos de idade e portanto é maior de idade`);
    }
    else{
        res.send(`O usuário ${nome}, tem ${idade} anos de idade e portanto é menor de idade`);
    }
});

app.listen(8081, ()=>{
    console.log("Servidor foi iniciado na porta 8081");
});



